package com.example.practica04;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.practica04.Clases.Post;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Activity_lista extends AppCompatActivity {

    ListView list;
    ArrayList<String> nombres = new ArrayList<>();
    public Button botonReturn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botonReturn = (Button) findViewById(R.id.btn_regreso);

        ArrayAdapter arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,titles);
        list = findViewById(R.id.listaInfo);

        list.setAdapter(arrayAdapter);


       botonReturn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(Activity_lista.this, MainActivity.class);
               startActivity(intent);
           }
       });

        public void resultado(String q){
            Retrofit retrofit = new Retrofit.Builder()

                    .baseUrl("https://jsonplaceholder.typicode.com/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            ServicioPost postService = retrofit.create(ServicioPost.class);
            Call<List<Post>> call = postService.find(q);
            call.enqueue(new Callback<List<Post>>() {
                @Override
                public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                    List<Post> postsList = response.body();
                    for (Post p: postsList){
                        String n = p.getName();
                        List<String> arrayNames;
                        arrayNames.add(n);
                    }
                }
                @Override
                public void onFailure(Call<List<Post>> call, Throwable t) {
                    Log.e(TAG, "onFailure: " + t.getMessage());
                }
            });
        }

    }

}