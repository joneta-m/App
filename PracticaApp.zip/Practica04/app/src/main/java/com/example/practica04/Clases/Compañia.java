package com.example.practica04.Clases;

public class Compañia {

}
