package com.example.practica04.Interfaces;
import com.example.practica04.Clases.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;


public interface Service {

    public interface PostService {
        @GET("comments")
        Call<List<Post>> find(@Query("id")String q);
    }
}
