package com.example.practica04;

import com.example.practica04.Clases.Post;

import java.util.List;

import retrofit2.Call;

public class ServicioPost {
    public Call<List<Post>> find(String q) {
    }
}
