package com.example.practica04;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {

    public EditText editTextNumero;
    public TextView txtnombre;
    public TextView txtapellidos;
    public TextView edad;
    private ImageButton botonNumero;
    private Button botonReturn;
    private final int PHONE_CALL_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        botonReturn = (Button) findViewById(R.id.btn_regreso);
        txtnombre = (TextView) findViewById(R.id.txt_nombre);
        txtapellidos = (TextView) findViewById(R.id.txt_apellidos);
        edad = (TextView) findViewById(R.id.txt_edad);
        editTextNumero = (EditText) findViewById(R.id.editTextNumero);
        botonNumero = (ImageButton) findViewById(R.id.botonNum);



        botonReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ir_act1 = new Intent(v.getContext(),MainActivity.class);
                startActivity(ir_act1);
            }
        });

        botonNumero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num = editTextNumero.getText().toString();
                if (num != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, PHONE_CALL_CODE);
                    } else {
                        versionesAnteriores(num);
                    }
                }
            }

            private void versionesAnteriores(String num) {
                Intent llamada = new Intent(Intent.ACTION_CALL, Uri.parse("tel: " + num));
                if (verificarPermisos(Manifest.permission.CALL_PHONE)) {
                    startActivity(llamada);
                } else {
                    Toast.makeText(MainActivity2.this, "Configura los permisos", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }


        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            switch (requestCode){
                case PHONE_CALL_CODE:
                    String permission = permissions[0];
                    int result = grantResults[0];
                    if(permission.equals(Manifest.permission.CALL_PHONE)){
                        if(result == PackageManager.PERMISSION_GRANTED){
                            String phonenumber = editTextNumero.getText().toString();
                            Intent llamada = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+ phonenumber));
                            if(ActivityCompat.checkSelfPermission(this,Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return;
                            startActivity(llamada);
                        }else{
                            Toast.makeText(this, "No aceptaste el permiso", Toast.LENGTH_SHORT).show();
                        }
                    }
                    break;
                default:
                    super.onRequestPermissionsResult(requestCode,permissions,grantResults);
                    break;
            }
        }

        private boolean verificarPermisos(String permiso){
            int resultado = this.checkCallingOrSelfPermission(permiso);
            return resultado == PackageManager.PERMISSION_GRANTED;
        }
}
